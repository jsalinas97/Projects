/**************
Joseph Salinas
C# WPF Program
/**************

To any employer, or user that may be viewing this folder.

This application was designed using the Visual Studio compiler, coded in C#.

The application can be run from the .exe found in the CourseScheduleWPF, all classes that contribute to
this project can be found in the Classes folder.

Purpose: This is a WPF application that can open a file, and search for specific records depending
on the user's search entry.