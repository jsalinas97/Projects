package salinas.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * This class uses an array of the DailyAttractionUsage class in order to
 * perform a variety of different tasks for each element of the array.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 4/8/17
 *
 */
public class Park {	
	
	private String Name;
	private String Location;
	protected DailyAttractionUsage[] m_DailyAttractionUsage;
	/**
	 * Get method that will return the Name member variable value.
	 * 
	 * @return Returns the value of Name.
	 */
	public String getName()
	{
		return Name;
	}
	/**
	 * Set method that will set the passed in name to the 
	 * Name member variable of the park class.
	 * 
	 * @param n_Name New name value.
	 */
	public void setName(String n_Name)
	{
		Name = n_Name;
	}
	/**
	 * Get method that will return the Location member variable value.
	 * 
	 * @return Returns the value of Location.
	 */
	public String getLocation()
	{
		return Location;
	}
	/**
	 * Set method that will set the passed in location to the
	 * Location member variable of the Park class.
	 * 
	 * @param n_Location New Location value.
	 */
	public void setLocation(String n_Location)
	{
		Location = n_Location;
	}
	/**
	 * This method will Read in all data from a specified Scanner instance and will
	 * continue to read data into each element of the array.
	 * 
	 * @param s Scanner variable, used to read in data from.
	 */
	public void Read(Scanner s)
	{
		Name = s.nextLine();
		Location = s.nextLine();
		int NumofAtr = s.nextInt();
		s.nextLine();
		m_DailyAttractionUsage = new DailyAttractionUsage[NumofAtr];
		//Since arrays can't be resized, the new size is allocated to the array
		//of m_DailyAttractionUsage and new is called for each element of the newly
		//allocated size of the m_DailyAttractionUsage array.
		for (int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			
			m_DailyAttractionUsage[i] = new DailyAttractionUsage();
		}
		//This for-loop will read in all data for each element of the array and will
		//call nextLine() until the last element of the array is reached and no further
		//elements need to be read in.
		for(int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			if( i < (m_DailyAttractionUsage.length - 1))
			{
				m_DailyAttractionUsage[i].Read(s);
				s.nextLine();
			}
			else
			{
				m_DailyAttractionUsage[i].Read(s);
			}
		}
	}
	/**
	 * Write method that will write out all the elements of the array for the
	 * Park class.
	 * 
	 * @param ps PrintStream variable to write data out to.
	 */
	public void Write(PrintStream ps)
	{
		//Starts with writing out the name, location and amount of attractions (array size),
		//outside the loop since these values only need to be printed once.
		ps.printf("%s\n%s\n%d\n", Name, Location, m_DailyAttractionUsage.length);
		//For-loop that prints all the elements of each array.
		for (int i = 0; i < m_DailyAttractionUsage.length; i++) 
		{
			//if-else statement, will go to next line after the array is written (ps.println()),
			//when the array reaches the last element, there will be not further elements so
			//ps.println will not be run.
			if( i != (m_DailyAttractionUsage.length - 1))
			{
				
				m_DailyAttractionUsage[i].Write(ps);
				ps.println();
			}
			else
			{
				
				m_DailyAttractionUsage[i].Write(ps);
			}
		}
	}
	/**
	 * This method will generate a report based off the information read in by the Read 
	 * method.
	 * 
	 * @param ps PrintStream variable to print the report.
	 */
	public void Report(PrintStream ps)
	{
		
		ps.printf("Park Report\n"); //Report heading.
		ps.printf("___________\n");
		ps.printf("%s\n%s\n", Name, Location); //Starts off the report by using the read-in parkName and parkLocation data.
		ps.printf("\n");
		ps.printf("Attraction Data\n");
		ps.printf("\n");
		//Column format for the report, with Name and Description being left justified, and the other column headers being right justified.
		ps.printf("%-30s %-69s %5s %5s %5s %5s %5s %5s \n", "Name","Description", "Cap", "Mth", "Day", "Year", "Runs", "Customers");
		ps.printf("%-30s %-69s %5s %5s %5s %5s %5s %5s \n", "____","___________", "___", "___", "___", "____", "____", "_________");
		//Variables that will hold the total number of runs and customers, will be used in total calculations.
		int totalnumruns = 0;
		int totalcust = 0;
		//For-loop that will print all the data of each element of the array.
		for (int i = 0; i< m_DailyAttractionUsage.length; i++)
		{
			CalendarDate calendarData = m_DailyAttractionUsage[0].getDate();
			Attraction attractionData = m_DailyAttractionUsage[i].getAttraction();
			//Variables for Attraction Data
			String atrName = attractionData.getName();
			String Desc = attractionData.getDescription();
			int Cap = attractionData.getCapacity();
			//Variables for CalendarDate Data
			int Month = calendarData.getMonth();
			int Day = calendarData.getDay();
			int Year = calendarData.getYear();
			//Variable for NumRuns and CustomerUsage
			int NumRuns = m_DailyAttractionUsage[i].getNumRuns();
			int CustUsage = m_DailyAttractionUsage[i].getCustomerUsage();
			//Running total of the total NumRuns and CustomerUsage
			totalnumruns = totalnumruns + m_DailyAttractionUsage[i].getNumRuns();
			totalcust = totalcust + m_DailyAttractionUsage[i].getCustomerUsage();
			//Printing out all variables in a neat format.
			ps.printf("%-30s %-69s %5s %5s %5s %5s %5s %5s \n", atrName, Desc, Cap, Month, Day, Year, NumRuns, CustUsage);
		}
		//Prints a total row that shows the total number of runs and customers.
		ps.printf("%-30s %-69s %5s %5s %5s %5s %5s %5s \n", "____","___________", "___", "___", "___", "____", "____", "_________");
		ps.printf("%-30s %99s %5s \n", "Total", totalnumruns, totalcust );	
	}
	/**
	 * This method will return the JSON string for the Park class.
	 * 
	 * @return Returns the each element of the array in JSON format.
	 */
	public String getJSON()
	{
		
		String JSON;
		//JSON String before array data is added to the String
		JSON = "{" + "\n" + "\"name\"" + " : " + "\"" + Name + "\"" + "," + "\n" + "\"location\"" + " : " + "\"" + Location + "\"" +
				"," + "\n" + "\"dailyattractionusage\"" + " :" + "\n" + "[";
		//For-Loop to print the JSON format of each array, depending on the
		//number of elements in the array.
		for(int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			//If statement that will print a comma if there are more elements in the array,
			//and will print the closing bracket and curly brace if the last element of the
			//array has been reached.
			if(i != (m_DailyAttractionUsage.length - 1))
			{
				
			JSON = JSON + "\n" + m_DailyAttractionUsage[i].getJSON() + ",";
			}
			else
			{
				
			JSON = JSON + "\n" + m_DailyAttractionUsage[i].getJSON()  + "\n" + "]" + "\n" + "}";
			}	
		}		
		return JSON;
	}
	/**
	 * This method will override the toString method to return a String with
	 * descriptive text.
	 * 
	 * @return Returns the newly created String.
	 */
	@Override
	public String toString() 
	{
		
		String s = "Park Name: " + Name + "\n" + "Location: " + Location + "\n";;
		//For-loop that prints each element of the array depending on
		//the length of the array.
		for(int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			//If statement that will print a new line unless the
			//last element of the array is reached.
			if(i != (m_DailyAttractionUsage.length - 1))
			{
				s = s + m_DailyAttractionUsage[i] + "\n";
			}
			else
			{
				s = s + m_DailyAttractionUsage[i];
			}
		}	
		return s;
	}
	/**
	 * This method will return all information at the entered index number.
	 * 
	 * @param index Value used to go to a specific index of the array.
	 * @return Returns the instance of the array specified.
	 */
	public DailyAttractionUsage GetByIndex(int index) throws ArrayIndexOutOfBoundsException
	{
		
		if (index < 0 || index >= m_DailyAttractionUsage.length)
		{
			ArrayIndexOutOfBoundsException e = new ArrayIndexOutOfBoundsException();
			throw e;
		}
		else
		{
		return m_DailyAttractionUsage[index];
		}
	}
	/**
	 * This method will find the attraction with the most customer usage and will
	 * return the element of the array that has the most customer usage.
	 * 
	 * @return result Returns the result, or element of the array containing the highest customer usage.
	 */
	public DailyAttractionUsage GetMostDailyUsage()
	{
		DailyAttractionUsage result = new DailyAttractionUsage();
		
		for(int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			
			if ( result.getCustomerUsage() < m_DailyAttractionUsage[i].getCustomerUsage())
			{
				result = m_DailyAttractionUsage[i];
			}	
		}
		return result;
	}
	/**
	 * Method that returns the total customer usage among all attractions.
	 * 
	 * @return Returns value for the total customer usage.
	 */
	public int TotalCustomerUsage()
	{
		int total = 0;
		
		for(int i = 0; i < m_DailyAttractionUsage.length; i++)
		{
			total = total + m_DailyAttractionUsage[i].getCustomerUsage();
		}
		
		return total;
	}
	/**
	 * Method that returns the size of the m_DailyAttractionUsage array.
	 * 
	 * @return Returns the size of the array.
	 */
	public int getArraySize()
	{
		
		int length = m_DailyAttractionUsage.length;
		return length;
	}
	/**
	 * Default constructor of the Park class.
	 */
	public Park()
	{
		
		m_DailyAttractionUsage = new DailyAttractionUsage[4];
		m_DailyAttractionUsage[0] = new DailyAttractionUsage();
		m_DailyAttractionUsage[1] = new DailyAttractionUsage();
		m_DailyAttractionUsage[2] = new DailyAttractionUsage();
		m_DailyAttractionUsage[3] = new DailyAttractionUsage();
		Name = " ";
		Location = " ";
	}
}
