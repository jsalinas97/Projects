package salinas.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Class that contains methods using data from the CalendarDate and Attraction
 * classes, contains many methods that will perform different tasks.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 3/15/2017
 *
 * */
public class DailyAttractionUsage {

	private Attraction Attraction;
	private CalendarDate Date;
	private int NumRuns;
	private int CustomerUsage;
	/**
	 * getNumRuns function, returns the value NumRuns
	 * 
	 * @return Value for NumRuns is returned.
	 */
	public int getNumRuns()
	{
		
		return NumRuns;
	}
	/**
	 * setNumRuns function, sets the value of NumRuns.
	 * 
	 * @param n_NumRuns Passed-in integer value which is assigned to NumRuns.
	 */
	public void setNumRuns(int n_NumRuns)
	{
		
		NumRuns = n_NumRuns;
	}
	/**
	 * getCustomerUsage function, returns CustomerUsage
	 * 
	 * @return Value for CustomerUsage is returned.
	 */
	public int getCustomerUsage()
	{
		
		return CustomerUsage;
	}
	/**
	 * setCustomerUsage function, sets the value for the CustomerUsage variable.
	 * 
	 * @param n_CustomerUsage Passed-in integer value which is assigned to CustomerUsage.
	 */
	public void setCustomerUsage(int n_CustomerUsage)
	{
		
		CustomerUsage = n_CustomerUsage;
	}
	/**
	 * setAttraction method that sets the values for all member variables of the
	 * Attraction class.
	 * 
	 * @param n_Name Passed-in String value, assigned to Name.
	 * @param n_Capacity Passed-in integer value, assigned to Capacity.
	 * @param n_Description Passed-in String value, assigned to Description.
	 */
	public void setAttraction(String n_Name, int n_Capacity, String n_Description)
	{
		
		Attraction.setName(n_Name);
		Attraction.setCapacity(n_Capacity);
		Attraction.setDescription(n_Description);
	}
	/**
	 * getAttraction method, returns Attraction data.
	 * 
	 * @return Attraction data is returned.
	 */
	public Attraction getAttraction()
	{
		
		return Attraction;
	}
	/**
	 * setDate method that sets the values for all member variable of the
	 * CalendarDate class.
	 * 
	 * @param n_Month Passed-in integer value, assigned to Month.
	 * @param n_Day Passed-in integer value, assigned to Day.
	 * @param n_Year Passed-in integer value, assigned to Year.
	 */
	public void setDate(int n_Month, int n_Day, int n_Year)
	{
		
		Date.setMonth(n_Month);
		Date.setDay(n_Day);
		Date.setYear(n_Year);
	}
	/**
	 * getDate method, returns data of type CalendarDate
	 * 
	 * @return CalendarDate data
	 */
	public CalendarDate getDate()
	{
		
		return Date;
	}
	/**
	 * Write method that takes in a PrintStream variable, and will output information
	 * depending on the declared PrintStream instance.
	 * 
	 * @param ps Passed-in PrintStream variable.
	 */
	public void Write(PrintStream ps)
	{
	
		Attraction.Write(ps);//Using Attraction's Write method.
		ps.printf("\n");
		Date.Write(ps);//Using CalendarDate's Write method.
		ps.printf("\n%d\n%d", NumRuns, CustomerUsage);	
	}
	/**
	 * Read method that takes in a Scanner variable, and will read-in information
	 * depending on the declared Scanner variable.
	 * 
	 * @param s Scanner Variable
	 */
	public void Read(Scanner s)
	{
		
		Attraction.Read(s); //Using Attraction's read method.
		Date.Read(s); //Using CalendarDate's read method.
		NumRuns = s.nextInt();
		CustomerUsage = s.nextInt();
	}
	/**
	 * getJSON method, returns DailyAttractionUsage data in JSON format.
	 * 
	 * @return Returns JSON string.
	 */
	public String getJSON()
	{
		
		String JSON;
		//Using the getJSON method from both CalendarDate and Attraction classes to assist with the JSON string creation.
		JSON = "{" + "\n" + "\"attraction\"" + " " + ":" + "\n" +  Attraction.getJSON() + "," + "\n" + "\"date\"" + " " + ":" + "\n" + Date.getJSON() + "," + "\n" +
		"\"numRuns\"" + " " + ":" + " " + NumRuns + "," + "\n" + "\"customerUsage\"" + " " + ":" + " " + CustomerUsage + "\n" + "}";
		return JSON;
	}
	/**
	 * toString method, returns DailyAttractionUsage data with descriptive text.
	 * 
	 * @return Returns String variable.
	 */
	@Override
	public String toString() 
	{
		//Using Attraction and CalendarDate toString methods to assist in creating the String.
		String s = Attraction.toString() + "\n" + Date.toString() + "\n" + "Num Runs:" + " " + NumRuns + "\n" + "Customer Usage:" + " " + CustomerUsage;
		return s;
	}
	/**
	 * Default Constructor of class DailyAttractionUsage.
	 */
	public DailyAttractionUsage()
	{
		
		NumRuns = 0;
		CustomerUsage = 0;
		//Calling new to Attraction.
		Attraction = new Attraction(); 
		Attraction.setCapacity(0);
		Attraction.setDescription(" ");
		Attraction.setName(" ");
		//Calling new to CalendarDate.
		Date = new CalendarDate();
		Date.setDay(0);
		Date.setMonth(0);
		Date.setYear(0);
	}
	
}
