package salinas.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/** 
 * Class that contains methods to utilize private member variables
 * and their values to perform a variety of different tasks.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 2/24/17
 * 
 * */

public class Attraction {
	//Private member variables
	private String Name;
	private int Capacity;
	private String Description;
	//Public methods
	/** 
	 * Get method for the Name private member variable, returns Name.
	 * 
	 * @return Name value is returned.
	 * 
	 * */
	public String getName()
	{ 
		
		return Name;
	}
	/** 
	 * Get method for the Capacity private member variable, returns Capacity.
	 * 
	 * @return Capacity value is returned.
	 * */
	public int getCapacity()
	{ 
		
		return Capacity;
	}
	/** 
	 * Get method for the Description private member variable, returns Description.
	 * 
	 * @return Description value is returned.
	 * */
	public String getDescription()
	{
		
		return Description;
	}
	/**
	 * Set method for Name private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param n_Name New String for Name.
	 */
	public void setName(String n_Name)
	{
		
		Name = n_Name;
	}
	/**
	 * Set method for Capacity private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param n_Capacity New int for Capacity.
	 */
	public void setCapacity(int n_Capacity)
	{ 
		
		Capacity = n_Capacity;
	}
	/**
	 * Set method for Description private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param n_Description New String for Description.
	 */
	public void setDescription(String n_Description)
	{
		
		Description = n_Description;
	}
	/**
	 * Read method, takes a passed-in scanner variables, and reads
	 * data from the declared scanner instance.
	 * 
	 * @param s Scanner variable
	 */
	public void Read(Scanner s)
	{
		
		Name = s.nextLine();
		Capacity = s.nextInt();
		s.nextLine();
		Description = s.nextLine();
	}
	/**
	 * Write method, writes data to a file through a 
	 * passed-in scanner variable.
	 * 
	 * @param ps Scanner variable
	 */
	public void Write(PrintStream ps)
	{
	
		ps.printf("%s\n%d\n%s", Name, Capacity, Description);	
	}
	/**
	 * getJSON method, returns a string in JSON format.
	 * 
	 * @return Returns String in JSON format.
	 */
	public String getJSON()
	{
		
		String JSON = "{" + "\"name\"" + ":" + "\"" + Name + "\"" + "," + "\n" + "\"capacity\"" + ":" + Capacity + "," + "\n" + "\"description\"" + ":" + "\"" + Description + "\"" + "}";
		return JSON;
	}
	/**
	 * toString method, returns a string with descriptive text.
	 * 
	 * @return Returns String value.
	 */
	@Override
	public String toString()
	{
		
		String s = "Attraction Name:" + " " + Name + "\n" + "Capacity:" + " " + Capacity + "\n" + "Description:" + " " + Description;
		return s;		
	}
	/** 
	 * Default constructor of the Attraction class.
	 * */
	public Attraction()
	{
		
		Name = "";
		Capacity = 0;
		Description = "";
	}
	/**
	 * Overloaded constructor for the Attraction class.
	 * 
	 * @param n_Name Returns new Name value.
	 * @param n_Capacity Returns new Capacity value.
	 * @param n_Description Returns new Description value.
	 */
	public Attraction(String n_Name, int n_Capacity, String n_Description)
	{
		Name = n_Name;
		Capacity = n_Capacity;
		Description = n_Description;	
	}
}
