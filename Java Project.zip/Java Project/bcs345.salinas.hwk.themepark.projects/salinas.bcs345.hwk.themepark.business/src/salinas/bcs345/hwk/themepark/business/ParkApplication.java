package salinas.bcs345.hwk.themepark.business;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
/**
 * ParkApplication class contains one method called start which allows
 * the application to function. This function displays both Park and Attraction
 * data and can perform a variety of different actions.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 4/28/17
 *
 */
public class ParkApplication extends Application 
{
	private Park park;
	private VBox m_vBox;
	private GridPane grid;
	private TabPane tabPane;
	private FileChooser fileChooser;
	private File selectedFile;
	private TextField parkField;
	private TextField locationField;
	private TextField customerField;
	private Label parkLabel;
	private Label locationLabel;
	private Label customerLabel;
	private ObservableList<DailyAttractionUsage> data;
	/**
	 * The start method contains the code in order for the application to run.
	 */
	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		//Calling new on the Park instance.
		park = new Park();
		//Called new on the GridPane instance.
		//GridPane is used to organize Labels and TextFields to pass into the appropriate tab.
		grid = new GridPane();
		//Setting the Vertical and Horizontal gap for the GridPane.
		grid.setVgap(8);
		grid.setHgap(20);
		//Calling new on the TabPane instance.
		tabPane = new TabPane();
		//Making the closing feature on each tab unavailable.
		tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
		//Declaring a new tab, parkTab.
		Tab parkTab = new Tab("Park");
		//Creating a Label and TextField for the Park Name section.
		parkLabel = new Label("Park Name");
		//Setting position for parkLabel.
		GridPane.setConstraints(parkLabel, 0, 0);
		//TextField instance for parkField variable, takes default name.
		parkField = new TextField(park.getName());
		parkField.setEditable(false);
		//Setting position for parkField.
		GridPane.setConstraints(parkField, 1, 0);
		//Creating a Label and TextField for the Park Location section.
		locationLabel = new Label("Park Location");
		//Setting position for locationLabel.
		GridPane.setConstraints(locationLabel, 0, 1);
		//TextField instance for locationField variable, takes default location.
		locationField = new TextField(park.getLocation());
		locationField.setEditable(false);
		//Setting position for locationField.
		GridPane.setConstraints(locationField, 1, 1);
		//Creating a Label and TextField for the Total Customer Usage section.
		customerLabel = new Label("Total Customer Usage");
		//Setting position for customerLabel.
		GridPane.setConstraints(customerLabel, 0, 2);
		//TextField instance for customerField variable, takes default customer usage.
		customerField = new TextField(String.valueOf(park.TotalCustomerUsage()));
		customerField.setEditable(false);
		//Setting position for customerField.
		GridPane.setConstraints(customerField, 1, 2);
		//Adds all Labels and TextFields to the GridPane.
		grid.getChildren().addAll(parkLabel, parkField, locationLabel, locationField, customerLabel, customerField);
		//Passing in the GridPane instance into the parkTab.
		parkTab.setContent(grid);
		//Creating new instance of Tab, attractionTab.
		Tab attractionTab = new Tab("Attractions");
		//ObservableList instance which will be passed into the ListView instance.
		data = FXCollections.<DailyAttractionUsage>observableArrayList();
		//For-loop that will add each instance of DailyAttractionUsage to the ObservableList
		//depending on the length of the array, will add default values in this case.
		for(int i = 0; i < park.getArraySize(); i++)
			{
			
			data.add(park.GetByIndex(i));
			}
		//ListView instance that will print the data in a ListView format.
		ListView<DailyAttractionUsage> listView = new ListView<DailyAttractionUsage>(data);
		//Passes in ListView instance to attractionTab.	
		attractionTab.setContent(listView);
		//Adds the parkTabe and attractionTab to the TabPane.
		tabPane.getTabs().addAll(parkTab, attractionTab);
		//Creating MenuBar instance, used for menu items.
		MenuBar menuBar = new MenuBar();
		//Adding first element of the MenuBar, File.
		Menu fileMenu = new Menu("File");
		menuBar.getMenus().add(fileMenu);
		//Creating Open Menu option.
		MenuItem openMenu = new MenuItem("Open...");
		fileMenu.getItems().add(openMenu);
		SeparatorMenuItem  separator = new SeparatorMenuItem();
		fileMenu.getItems().add(separator);
		//Creating Save Menu option.
		MenuItem saveMenu = new MenuItem("Save As...");
		fileMenu.getItems().add(saveMenu);
		//Creating Save Report option.
		MenuItem saveReport = new MenuItem("Save Report...");
		fileMenu.getItems().add(saveReport);
		SeparatorMenuItem  secondsep = new SeparatorMenuItem();
		fileMenu.getItems().add(secondsep);
		//Creating Export As JSON option.
		MenuItem saveJSON = new MenuItem("Export As JSON...");
		fileMenu.getItems().add(saveJSON);
		SeparatorMenuItem thirdsep = new SeparatorMenuItem();
		fileMenu.getItems().add(thirdsep);
		//Creating Exit option.
		MenuItem exit = new MenuItem("Exit");
		fileMenu.getItems().add(exit);
		//Event handler for the Open Menu option.
		openMenu.setOnAction(new EventHandler<ActionEvent>() 
			{
				/**
				* This method handles the event for the Open... menu item.
				*/
				public void handle(ActionEvent t) 
				{
					//New FileChooser instance is created for openMenu.
					fileChooser = new FileChooser();
					fileChooser.setTitle("Open Park File");
					//Presents user with an Open Dialog window and will save the selected file.
					selectedFile = fileChooser.showOpenDialog(primaryStage);
					if (selectedFile != null) 
					{
						try {
								//Clears all previous default data in the observable list.
								data.clear();
						 		//Scanner instance holding the File variable, selectedFile.
						 	 	Scanner reader = new Scanner(new FileReader(selectedFile));
						 	 	//Reads in data from instance of Scanner created.
						 	 	park.Read(reader);
						 	 	//Updating all fields values, so that after a file is opened
						 	 	//the values will be updated while the program is running.
						 	 	//Updating Name, Location, and TotalCustomerUsage.
						 	 	parkField.setText(park.getName());
						 	 	locationField.setText(park.getLocation());
						 	 	customerField.setText(String.valueOf(park.TotalCustomerUsage()));
						 	 	//Updating listView layout for the Attractions tab.
						 	 	//data = FXCollections.<DailyAttractionUsage>observableArrayList(); 
						 		//For loop that re-adds new data read in from file.
						 	 	for(int i = 0; i < park.getArraySize(); i++)
						 		{
						 			data.add(park.GetByIndex(i));
						 		}
						 		ListView<DailyAttractionUsage> listView = new ListView<DailyAttractionUsage>(data);
						 		//Setting new content for the attractions tab.
						 		attractionTab.setContent(listView);
						 	} 
						catch(FileNotFoundException e) 
							{
								e.printStackTrace();
							}
							
					}
				}
			}
		);
		//Event handler for the Save As... menu item.
		saveMenu.setOnAction(new EventHandler<ActionEvent>() 
			{
				/**
				* This method handles the event for the Save As... menu item.
				*/
				public void handle(ActionEvent t) 
				{
					//New FileChooser instance is created for saveMenu.
					fileChooser = new FileChooser();
					fileChooser.setTitle("Save As Park");
					selectedFile = fileChooser.showSaveDialog(primaryStage);
					if (selectedFile != null) 
					{
						try {
								//Saves Park data to desired location.
								PrintStream ps = new PrintStream(selectedFile);
								park.Write(ps);
						 	} 
						catch (FileNotFoundException e) 
						 	{
								e.printStackTrace();
						 	}
					}
				}
			}
		);
		//Event handler for the Save Report... menu item.
		saveReport.setOnAction(new EventHandler<ActionEvent>() 
			{
				/**
				* This method handles the event for the Save Report... menu item.
				*/
				public void handle(ActionEvent t) 
				{
					//New FileChooser instance is created for saveReport.
					fileChooser = new FileChooser();
					fileChooser.setTitle("Save Park Report");
					selectedFile = fileChooser.showSaveDialog(primaryStage);
					if (selectedFile != null) 
					{
						try {
								//Prints the selected file to desired location.
							 	PrintStream ps = new PrintStream(selectedFile);
							 	park.Report(ps);
						 	} 
						catch (FileNotFoundException e) 
							{
								e.printStackTrace();
						 	}
					}
				}
			}
		);
		//Event handler for the Export As JSON... menu item.
		saveJSON.setOnAction(new EventHandler<ActionEvent>() 
			{
				/**
				* This method handles the event for the Export As JSON... menu item.
				*/
				public void handle(ActionEvent t) 
				{
					//New FileChooser instance is created for saveJSON.
					fileChooser = new FileChooser();
					fileChooser.setTitle("Export As JSON");
					selectedFile = fileChooser.showSaveDialog(primaryStage);
					if (selectedFile != null) 
					{
						try { 
								//Prints JSON format to the desired location.
								PrintStream ps = new PrintStream(selectedFile);
							 	ps.printf("%s", park.getJSON());
						 	} 
						catch (FileNotFoundException e) 
						 	{
								e.printStackTrace();
						 	}
					}
				}
			}
		);
		//Event handler for the Exit menu item.
		exit.setOnAction(new EventHandler<ActionEvent>() 
			{
				/**
				* This method handles the event for the Exit menu item.
				*/
				public void handle(ActionEvent t) 
				{
					//Line of code to shutdown application.
					System.exit(0);
				}
			}
		);
		//Creating a VBox and adding the menuBar and tabPane.
		m_vBox = new VBox();
		m_vBox.getChildren().add(menuBar);
		m_vBox.getChildren().add(tabPane);
		//Creating the Scene for the application.
		Scene scene = new Scene(m_vBox, 350, 350);
		primaryStage.setTitle("Park Data");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
