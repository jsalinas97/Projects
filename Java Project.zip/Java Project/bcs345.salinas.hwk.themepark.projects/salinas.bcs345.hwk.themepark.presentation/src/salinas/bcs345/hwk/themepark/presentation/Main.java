package salinas.bcs345.hwk.themepark.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import salinas.bcs345.hwk.themepark.business.Park;

/** 
 * Contains the main class, the user is presented when a menu UI to selected from a variety of 
 * different UIs such as  DailyAttractionUsageConsoleUI, ParkConsoleUI and ParkGraphicalUI. 
 * These UIs can perform a variety of different tasks depending on the user's selection.
 * 
 * @author Joseph Salinas
 * @version 2.0
 * @since 4/8/17
 * 
 * 
 * */

public class Main 
{

	/**
	* Provides the user with a Menu UI in order to choose between the three DailyAttractionConsoleUI,
	* ParkConsoleUI and ParkGraphicalUI menus.	
	* 
	* @param args Default parameter of main
	* @throws FileNotFoundException Prevents a FileNotFoundException error
	*/
	public static void main(String[] args) throws FileNotFoundException 

	{
	
		int choice = 0; //Variable used to hold choice value.
		ParkConsoleUI parkUI = new ParkConsoleUI();
		DailyAttractionUsageConsoleUI dailyUI = new DailyAttractionUsageConsoleUI();
		ParkGraphicalUI graphicalUI = new ParkGraphicalUI();
		Scanner keyboard = new Scanner(System.in);
		//Do-while loop will always provide the menu until the user decides to exit.
		do
		{
			
			System.out.println("Menu UI");
			System.out.println("__________________________");
			System.out.println("1 - DailyAttractionConsoleUI");
			System.out.println("2 - ParkConsoleUI");
			System.out.println("3 - ParkGraphicalUI");
			System.out.println("4 - Exit");
			System.out.print("Enter Choice:");
			choice = keyboard.nextInt();
			//While loop to check for a valid choice number, if choice number is invalid,
			//the user will have to re-enter their choice.
			while(choice > 4 || choice < 1)
			{
				System.out.println("Invalid choice, please enter a choice from 1-3:");
				choice = keyboard.nextInt();
			}
			keyboard.nextLine();
			switch(choice)
			{
				//Case 1 will present the DailyAttractionUsage UI.
				case 1:
						dailyUI.ShowUI();
						break;
				//Case 2 will present the Park UI.
				case 2:
						parkUI.ShowUI();
						break;
				//Case 3 will present the ParkGraphical UI.		
				case 3:
						graphicalUI.ShowUI();
						break;
			}
			
		} while (choice != 4);
		keyboard.close();//Closes the keyboard Scanner variable.
	}
}

	

		
