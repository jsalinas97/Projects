package salinas.bcs345.hwk.themepark.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import salinas.bcs345.hwk.themepark.business.DailyAttractionUsage;

/**
 * Class that contains a method to provide the user with a menu, in which a variety
 * of different selections are given to the user. Upon selection,
 * a specific task will be performed.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 3/14/17
 *
 */
public class DailyAttractionUsageConsoleUI 
{
	/**
	 * The ShowUI method presents the user with a menu of five choices,
	 * depending on the choice given by the user will determine what task will
	 * be performed.
	 * 
	 * @throws FileNotFoundException Used to avoid errors with file writing.
	 */
	public void ShowUI() throws FileNotFoundException 
	{
		int choice = 0; //Variable used to hold choice value.
		DailyAttractionUsage usage = new DailyAttractionUsage();
		Scanner keyboard = new Scanner(System.in);
		//Do-while loop will always provide the menu until the user decides to exit.
		do
		{
			
			System.out.println("Daily Attraction Usage UI");
			System.out.println("__________________________");
			System.out.println("1 - Read daily usage from file");
			System.out.println("2 - Write daily usage to file");
			System.out.println("3 - Show daily usage info with descriptive text on screen");
			System.out.println("4 - Show daily usage JSON on screen");
			System.out.print("5 - Exit");
			System.out.println("Enter Choice:");
			choice = keyboard.nextInt();
			//While loop to check for a valid choice number, if choice number is invalid,
			//the user will have to re-enter their choice.
			while(choice > 5 || choice < 1)
			{
				System.out.println("Invalid choice, please enter a choice from 1-5:");
				choice = keyboard.nextInt();
			}
			keyboard.nextLine();
			switch(choice)
			{
				//Case 1 Reads in a file name by using the keyboard scanner to read in a name, 
				//and passes scanner variable to Read method.
				case 1:
						//Try-catch block to return the user to the main menu upon trying to read an invalid file,
						//prevents program from crashing, recovers by returning to main menu.
						try{
						
								System.out.println("Enter in a file name to read: ");
								String filename = keyboard.nextLine();
								Scanner reader = new Scanner(new FileReader(filename));
								usage.Read(reader);
								break;
							}
						catch(FileNotFoundException x)
							{
					
								System.out.println("File could not be found, returning to main menu.");
								break;
							}
				//Case 2 Reads in a file name for the output, using the keyboard scanner and
				//passes PrintStream variable to the Write method.
				case 2:
						System.out.println("Enter in a file name to write out to:");
						String outfile = keyboard.nextLine();
						PrintStream ps = new PrintStream(outfile);
						usage.Write(ps);
						break;
				//Case 3 prints out what is returned from the toString method.
				case 3:
						System.out.println();
						System.out.println(usage.toString());
						System.out.println();
						break;
				//Case 4 prints out what is returned from the getJSON method.
				case 4:
						System.out.println();
						System.out.println(usage.getJSON());
						System.out.println();
						break;
		}
			System.out.println();
		}while (choice != 5);
		
	}

}
