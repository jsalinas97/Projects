/**************
Joseph Salinas
Java Project
/**************

To any employer, or user that may be viewing this folder.

This application was designed using the Eclipse compiler, coded in Java.

Both folders are to be imported to the compiler for this project to run. The project runs from the
presentation folder.

Purpose: This is an application that manages file data, and uses file input/output to 
perform certain tasks.

From the menu

1 - Uses the DailyAttractionUsage.txt file to manipulate data (Console Application)
2- Uses the Park.txt file to manipulate data (Console Application)
3 - Uses the Park.txt file to manipulate data (GUI Application)